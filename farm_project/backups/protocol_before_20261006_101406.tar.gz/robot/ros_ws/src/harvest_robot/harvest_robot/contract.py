"""HarvestTask 입력 검사와 이동 전용 결과 계약. ROS import 없이 검사 가능합니다."""
import math
import re


def validate_task(goal, config: dict) -> None:
    task = goal.harvest_task
    match = re.fullmatch(r'(SEC\d{2,})_(G\d{2,})_W\d{2,}', task.window_id)
    if not match or not task.task_id:
        raise ValueError('task_id/window_id 형식 오류')
    section, segment = match[1], match[1] + '_' + match[2]
    if task.section_id != section or task.segment_id != segment or task.sequence < 1:
        raise ValueError('Section/Segment/Window/sequence 불일치')
    if segment not in config['segments']:
        raise ValueError('등록되지 않은 관측 Segment')
    if goal.robot_id != config['robot_id'] or goal.map_id != config['map_id']:
        raise ValueError('robot_id/map_id 불일치')
    p, yaw = task.goal_pose.position, task.goal_pose.yaw
    if (task.goal_pose.frame_id != 'map' or task.expected_count < 0
            or not all(math.isfinite(v) for v in (p.x, p.y, p.z, yaw)) or abs(p.z) > .1):
        raise ValueError('목표 pose/expected_count 오류')


def result_fields(goal, code: str, error_code: str = 'NONE', message: str = '') -> dict:
    task = goal.harvest_task
    return dict(robot_id=goal.robot_id, task_id=task.task_id, window_id=task.window_id,
                result_code=code, expected_count=task.expected_count, harvested_count=0,
                failed_count=0, error_code=error_code, error_message=message)
