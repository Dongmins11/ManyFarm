# 프로젝트 구현 합의

- control/robot/sim 및 기존 패키지 역할을 유지한다. 런치 mode=sim/real로 환경별 설정과 장치를 선택하고 동일한 로봇 로직을 실행한다.
- 좌표·노드·엣지·베드 데이터를 코드에 고정하지 않는다. JSON/YAML/GeoJSON을 project_root 기준으로 로드한다. 양 환경의 베드는 직선이다.
- Node/Mission/Communication/StateController/States를 유지한다. Python _ 멤버와 snake_case를 사용한다. m_ 컨벤션으로 바꾸지 않는다.
- 각 State는 enter에서 행동을 요청하고 반환한다. 완료 콜백에서 전환을 요청하며 Controller가 exit/enter를 관리한다.
- 로봇별 관제 통신과 작업 의미는 각 로봇에 둔다. farm_interfaces는 형식 정의이며 공통 작업 실행기가 아니다.
- farm_navigation은 공통 주행·위치 조회 라이브러리다. ScoutNode 내부 변수나 예찰 도메인에 의존하지 않는다.
- kinematics는 장치가 필요한 경우 재사용한다. 기존 드라이버가 제공하는 odom/바퀴 제어를 중복 계산하지 않는다.
- 경로 계산과 실행은 분리한다. 미니관제 수확 이동은 자체 RouteToPose와 FollowPath였으며 ComputeRoute 사용으로 잘못 기록하지 않는다.
- 교통 제어·AprilTag·도킹은 별도 도입 범위다. 가짜 성공이나 빈 pause/resume 구현을 추가하지 않는다.
- 현재 시뮬 그래프는 베드별 16개 비연결 성분이다. 연결을 임의로 추가하거나 FollowPath 실패를 조용히 목적지 이동으로 대체하지 않는다.
- 실물 SEC_01 설정과 D435 어댑터는 기존 로봇 설정으로 연결했다. 실물 전체 주행 검증은 아직 하지 않았다. farm_real_devices는 기존 TurtleBot3/vicpinky 하드웨어 bringup을 재사용하며 파이캠은 포함하지 않는다. sim/real 설정 선택 지원과 실물 검증 완료를 구분한다.
- 이전 구현은 outputs/navigation_refactor 백업과 docs/NAVIGATION_REFACTOR_HISTORY.md에 기록했다. 실제 예찰 E2E 확인 전 기존 구현과 scout_new를 삭제·최종 교체하지 않는다.
- 코드 주석과 문서는 한국어로 책임·단위·호출 순서를 설명한다. 함수 인자와 반환 타입을 표시한다.

- 실물 지도는 사용자 지정 매니팜 지도다. robot/config/maps/many_farm의 many_farm.yaml/pgm 및 graph.geojson을 사용한다. graph.json은 이전 관제 참조 데이터이며 경로 계산 입력은 graph.geojson이다. 시뮬 지도와 혼용하지 않는다.

- 실물 설정은 robot/config/environments, robots, survey, vision, maps로 나눈다. 장치 설정 원본은 robots/burger/devices.json이며 farm_real_devices/config의 파일은 패키지 설치용 심볼릭 링크다. 중복 원본을 만들지 않는다.

## 시뮬레이션 통합 및 변경 관리 — 2026-10-02 사용자 요청

- 이번에 인수한 실물 담당자 소스를 통합 기준으로 삼는다. 이전 harvest-scout 실행은 사용자의 개별 시험이며, 해당 시험용 코드를 새 운영 기준에 자동 병합하거나 되살리지 않는다.
- 시뮬레이션에만 필요한 코드·설정·데이터·실행 도구·시험·문서는 `sim/` 안에서 작성하고 수정한다. 기존 시뮬 전용 파일이 `scripts/`나 `robot/`에 있다는 이유로 그 위치의 수정을 계속하지 않는다.
- `robot/ros_ws/src/`에는 실물 전용 코드뿐 아니라 양 환경이 사용하는 공통 코드가 있다. `farm_navigation`, `farm_vision`, `farm_common`, `farm_interfaces`, `farm_bringup`, `scout_robot`의 미션·통신·상태·과실 처리 변경은 공통 변경이다.
- 공통 코드 변경은 적용 전에 사용자에게 이유, 대상 파일, 구체적인 변경안, 실물·시뮬 영향, 검증 방법을 제시하고 명시적으로 확인받는다. 승인 전에는 적용 대상 소스를 수정하지 않는다. 제안용 diff는 별도 산출물로 준비할 수 있다.
- 공통 코드 복사본을 `sim/`에 만들어 업무 로직을 따로 고치거나, monkey patch로 공통 동작을 바꾸어 승인 절차를 우회하지 않는다. 시뮬 어댑터와 설정은 기존 공통 계약을 사용한다.
- 실물 설정 `robot/config/`와 공유 모델 `robot/models/`, 공용 실행·빌드 스크립트 및 기존 공통 시험의 변경도 영향 범위를 먼저 확인한다. 시뮬 전용 조정 때문에 실물 설정을 덮어쓰지 않는다.
- 변경마다 `sim/docs/CHANGELOG.md`에 일자, 구분, 대상 파일, 이유, 승인 근거/대기 상태, 변경 전후, 실물 영향, 검증 결과, 되돌리는 방법을 기록한다. 공통 변경은 승인 전 제안과 승인 후 적용을 구분한다.
- 시뮬 시험 결과·영상·로그는 새 설정부터 `sim/runs/` 등 `sim/` 내부로 분리한다. 이미 존재하는 공통 경로의 파일은 승인 없이 삭제하거나 이동하지 않는다.
- 환경 데이터에는 해당 환경의 지도·좌표·TF·센서 조건을 사용한다. 실물 노드 번호나 좌표를 시뮬 지도에 그대로 복사하지 않는다. 로봇 업무 FSM과 메시지 계약은 공통으로 유지한다.
- 실제 Isaac Sim 통합 시험과 오프라인 단위 시험 결과를 구분한다. 담당자 인수인계서에 적힌 실기 결과와 이번 작업에서 직접 확인한 결과도 구분한다.
- 하위 시뮬 작업 규칙은 `sim/AGENTS.md`, 이번 인수 검토는 `sim/docs/INTEGRATION_REVIEW_20261002.md`를 참고한다.


## 실행 단위 분리 — 2026-10-02 추가 승인

- 사용자 요청으로 공통 로봇 launch와 모니터링 launch를 분리했다. 예찰 launch 기본값은 장치+Nav2+예찰 서버이며 Isaac/RViz를 자동 실행하지 않는다.
- 시뮬 전체 조합 및 Isaac 시작은 sim 패키지의 all.launch.py/isaac.launch.py에 둔다. 로봇별 bringup에서 환경 시뮬레이터를 시작하지 않는다.
- RViz는 farm_bringup rviz.launch.py로 독립 실행한다. 실행 안내의 현재 기준은 docs/RUN_GUIDE_20261002.md다.
- 이번 공통 변경 승인은 실행 구조 분리 범위다. 공통 미션·주행 알고리즘·메시지와 실물 설정은 수정하지 않았다. 이후 공통 변경은 기존 확인 절차를 따른다.
