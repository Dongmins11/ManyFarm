"""Deterministic, non-destructive USD scene composition. Units: metres, Z-up.
Build-only requires numpy + usd-core; Isaac Sim already supplies them.
"""
import itertools
import json
import math
import os
import re
from pathlib import Path
import numpy as np
from pxr import Gf, Sdf, Usd, UsdGeom, UsdShade, Vt
ROOT=Path(__file__).resolve().parent
COLORS={'green':'Pepper_Green','red':'Pepper_Red','yellow':'Pepper_Yellow'}

def relative(path, directory):
    return os.path.relpath(path,directory).replace(os.sep,'/')

def bounds(cache,prim):
    r=cache.ComputeLocalBound(prim).ComputeAlignedRange()
    return np.array(r.GetMin()),np.array(r.GetMax())

def transform_points(points,matrix):
    points=np.asarray(points,dtype=float)
    homogeneous=np.column_stack((points,np.ones(len(points)))) @ np.array(matrix)
    return homogeneous[:,:3]/homogeneous[:,3:4]

def find_beds(stage,cfg):
    if UsdGeom.GetStageUpAxis(stage)!='Z' or abs(UsdGeom.GetStageMetersPerUnit(stage)-1)>1e-8:
        raise ValueError('Background must use Z-up and metres, as supplied.')
    cache=UsdGeom.BBoxCache(Usd.TimeCode.Default(),['default','render'])
    xf=UsdGeom.XformCache();beds=[]
    for p in stage.Traverse():
        match=re.fullmatch(r'Trellis_Frame_(\d+)',p.GetName())
        if not match or p.GetTypeName()!='Xform':continue
        i=int(match[1]);matrix=xf.GetLocalToWorldTransform(p)
        # Rigid XY rotation/translation is supported; reject non-unit scales or tilt.
        a=np.array(matrix)[:3,:3]
        if not np.allclose(a@a.T,np.eye(3),atol=1e-5) or not np.allclose(a[2],[0,0,1],atol=1e-5):
            raise ValueError(f'{p.GetPath()}: tilted/scaled beds require adaptation')
        lo,hi=bounds(cache,p);soil=stage.GetPrimAtPath(p.GetParent().GetPath().AppendChild(f'Soil_Surface_{i}'))
        if not soil:raise ValueError(f'Missing Soil_Surface_{i}')
        sl,sh=bounds(cache,soil)
        corners=np.array(list(itertools.product(*zip(sl,sh))))
        soil_local=transform_points(corners,xf.GetLocalToWorldTransform(soil)*matrix.GetInverse())
        soil_z=float(soil_local[:,2].max())
        beds.append({'id':i,'path':str(p.GetPath()),'matrix':matrix,'x':float((lo[0]+hi[0])/2),
            'y0':float(lo[1]+cfg['trellis_pipe_radius_m']),
            'y1':float(hi[1]-cfg['trellis_pipe_radius_m']),
            'outer_half_width':float((hi[0]-lo[0])/2),'soil_z':soil_z})
    beds.sort(key=lambda b:b['id'])
    if not beds:raise ValueError('No Trellis_Frame_XX + Soil_Surface_N found in background')
    return beds

def validate(cfg):
    for key in ['plants_per_bed','max_attempts_per_fruit']:
        if type(cfg[key])!=int or cfg[key]<1:raise ValueError(key+' must be a positive integer')
    for key in ['tree_height_m','fruit_scale_range','fruit_center_height_above_soil_m']:
        a,b=cfg[key]
        if not 0<a<=b:raise ValueError(key+' must be [positive min, max]')
    for key in ['canopy_width_m','canopy_length_m','trellis_pipe_radius_m','stem_radius_m','max_connector_length_m']:
        if cfg[key]<=0:raise ValueError(key+' must be positive')
    for key in ['wire_clearance_m','fruit_gap_m','plant_end_margin_m','root_bury_m']:
        if cfg[key]<0:raise ValueError(key+' must be nonnegative')
    if cfg['fruit_sides'] not in ['both','left','right']:raise ValueError('fruit_sides: both / left / right')
    for color,n in cfg['fruit_counts_per_bed'].items():
        if color not in COLORS or type(n)!=int or n<0:raise ValueError('Invalid fruit count or color')
    if not cfg['tree_variants']:raise ValueError('tree_variants cannot be empty')

def ref_asset(stage,path,asset,position,scale,yaw,output):
    xf=UsdGeom.Xform.Define(stage,path)
    xf.AddTranslateOp().Set(Gf.Vec3d(*position))
    xf.AddRotateZOp().Set(float(yaw))
    xf.AddScaleOp().Set(Gf.Vec3f(*scale))
    model=stage.DefinePrim(path+'/Model','Xform')
    model.GetReferences().AddReference(relative(asset,output.parent))
    model.SetInstanceable(True)
    return xf.GetPrim()

def branch_material(stage):
    mat=UsdShade.Material.Define(stage,'/World/Vegetation/Looks/Stem')
    sh=UsdShade.Shader.Define(stage,str(mat.GetPath())+'/Surface');sh.CreateIdAttr('UsdPreviewSurface')
    sh.CreateInput('diffuseColor',Sdf.ValueTypeNames.Color3f).Set(Gf.Vec3f(.075,.19,.028))
    sh.CreateInput('roughness',Sdf.ValueTypeNames.Float).Set(.8)
    mat.CreateSurfaceOutput().ConnectToSource(sh.ConnectableAPI(),'surface')
    return mat

def connector(stage,path,start,end,radius,mat):
    # Mesh tube, rather than a viewport-only line/curve.
    d=end-start;d/=np.linalg.norm(d)
    u=np.cross(d,[0,0,1])
    if np.linalg.norm(u)<1e-6:u=np.cross(d,[0,1,0])
    u/=np.linalg.norm(u);v=np.cross(d,u)
    pts=[p+radius*(math.cos(t)*u+math.sin(t)*v) for p in [start,end] for t in np.arange(8)*math.pi/4]
    faces=[[i,(i+1)%8,(i+1)%8+8,i+8] for i in range(8)]
    faces += [list(reversed(range(8))),list(range(8,16))]
    m=UsdGeom.Mesh.Define(stage,path)
    m.CreatePointsAttr(Vt.Vec3fArray.FromNumpy(np.array(pts,dtype=np.float32)))
    m.CreateFaceVertexCountsAttr([len(f) for f in faces]);m.CreateFaceVertexIndicesAttr([i for f in faces for i in f])
    m.CreateSubdivisionSchemeAttr('none');UsdShade.MaterialBindingAPI.Apply(m.GetPrim()).Bind(mat)

def build(config_path=None):
    config_path=Path(config_path or ROOT/'config.json').resolve()
    cfg=json.loads(config_path.read_text(encoding='utf-8'));validate(cfg)
    bg=(ROOT/cfg['background']).resolve();output=(ROOT/cfg['output']).resolve()
    if output==bg:raise ValueError('Output must not overwrite background')
    if output.suffix not in ['.usd','.usda','.usdc']:raise ValueError('Output must have USD extension')
    meta=json.loads((ROOT/'assets/manifest.json').read_text())
    for v in cfg['tree_variants']:
        if v not in meta or 'stem_points' not in meta[v]:raise ValueError('Unknown tree '+v)
    background=Usd.Stage.Open(str(bg));beds=find_beds(background,cfg)
    ids={str(b['id']) for b in beds}
    if set(cfg.get('bed_overrides',{}))-ids:raise ValueError('Unknown bed_overrides ID')
    output.parent.mkdir(parents=True,exist_ok=True)
    temporary=output.with_name(output.stem+'.building'+output.suffix)
    if temporary.exists():temporary.unlink()
    stage=Usd.Stage.CreateNew(str(temporary));stage.GetRootLayer().subLayerPaths=[relative(bg,output.parent)]
    UsdGeom.SetStageUpAxis(stage,'Z');UsdGeom.SetStageMetersPerUnit(stage,1)
    stage.SetDefaultPrim(stage.GetPrimAtPath('/World'))
    UsdGeom.Xform.Define(stage,'/World/Vegetation');mat=branch_material(stage)
    rng=np.random.default_rng(cfg['seed']);trees=[];fruits=[];warnings=[]
    try:
        if cfg['missing_hdri_fallback']:
            for p in stage.Traverse():
                a=p.GetAttribute('inputs:texture:file')
                if p.GetTypeName()=='DomeLight' and a:
                    val=a.Get()
                    if val and val.path and not val.resolvedPath:
                        a.Set(Sdf.AssetPath(''))
                        warnings.append(f'Missing HDRI {val.path}; used untextured dome light.')
        for bed in beds:
            local=dict(cfg);local.update(cfg.get('bed_overrides',{}).get(str(bed['id']),{}));validate(local)
            if local['trellis_pipe_radius_m']!=cfg['trellis_pipe_radius_m']:
                raise ValueError('trellis_pipe_radius_m is global only')
            for v in local['tree_variants']:
                if v not in meta or 'stem_points' not in meta[v]:raise ValueError('Unknown tree '+v)
            base=f"/World/Vegetation/Bed_{bed['id']:02d}"
            UsdGeom.Xform.Define(stage,base).AddTransformOp().Set(bed['matrix'])
            y0=bed['y0']+local['plant_end_margin_m'];y1=bed['y1']-local['plant_end_margin_m']
            if y0>=y1:raise ValueError('End margins consume bed')
            n=local['plants_per_bed'];ys=np.array([(y0+y1)/2]) if n==1 else np.linspace(y0,y1,n)
            candidates=[]
            for k,y in enumerate(ys):
                variant=local['tree_variants'][int(rng.integers(len(local['tree_variants'])))];m=meta[variant]
                size=np.diff(np.array(m['bounds']),axis=0)[0]
                scale=np.array([local['canopy_width_m']/size[0],local['canopy_length_m']/size[1],rng.uniform(*local['tree_height_m'])/size[2]])
                yaw=float(rng.choice([0,180]));sign=1 if yaw==0 else -1
                position=np.array([bed['x'],y,bed['soil_z']-local['root_bury_m']])
                path=base+f'/Trees/Tree_{k+1:03d}'
                ref_asset(stage,path,ROOT/'assets'/m['file'],position,scale,yaw,output)
                stem=np.array(m['stem_points'])*scale*np.array([sign,sign,1])+position
                zmin,zmax=np.array(local['fruit_center_height_above_soil_m'])+bed['soil_z']
                # Anchor is near the fruit's upper stem, so allow a small extra height.
                stem=stem[(stem[:,2]>=zmin+.025)&(stem[:,2]<=zmax+.07)]
                if len(stem):candidates.append((path,stem))
                trees.append({'path':path,'variant':variant,'bed':bed['id'],'position_world':transform_points([position],bed['matrix'])[0].tolist(),'scale':scale.tolist(),'yaw_deg':yaw})
            labels=[c for c,count in local['fruit_counts_per_bed'].items() for _ in range(count)];rng.shuffle(labels)
            if labels and not candidates:raise ValueError('No tree stems in requested fruit height range')
            accepted=[]
            for index,color in enumerate(labels):
                m=meta[COLORS[color]]
                for attempt in range(local['max_attempts_per_fruit']):
                    treepath,stem=candidates[int(rng.integers(len(candidates)))]
                    side=int(rng.choice([-1,1])) if local['fruit_sides']=='both' else (-1 if local['fruit_sides']=='left' else 1)
                    scale=float(rng.uniform(*local['fruit_scale_range']));radius=m['radius']*scale
                    yaw=float(rng.uniform(-180,180));angle=math.radians(yaw)
                    rot=np.array([[math.cos(angle),-math.sin(angle),0],[math.sin(angle),math.cos(angle),0],[0,0,1]])
                    # Prefer outer branches, not interior trunk, as the attachment source.
                    outer=stem[side*(stem[:,0]-bed['x'])>=np.quantile(side*(stem[:,0]-bed['x']),.65)]
                    anchor=outer[int(rng.integers(len(outer)))].copy()
                    offset=rot@(np.array(m['attachment'])*scale)
                    center=np.array([bed['x']+side*(bed['outer_half_width']+local['wire_clearance_m']+radius),anchor[1]-offset[1],anchor[2]-offset[2]])
                    if not zmin<=center[2]<=zmax:continue
                    if not bed['y0']+radius<=center[1]<=bed['y1']-radius:continue
                    endpoint=center+offset
                    if np.linalg.norm(endpoint-anchor)>local['max_connector_length_m']:continue
                    if any(np.linalg.norm(center-prev)<radius+rr+local['fruit_gap_m'] for prev,rr in accepted):continue
                    break
                else:
                    raise RuntimeError(f"Bed {bed['id']}: cannot place {len(labels)} fruits with current spacing/heights. Reduce counts or widen height range. Existing output preserved.")
                path=base+f'/Fruits/Pepper_{index+1:04d}_{color}'
                prim=ref_asset(stage,path,ROOT/'assets'/m['file'],center,[scale]*3,yaw,output)
                for key,value in [('color',color),('sourceTree',treepath)]:prim.CreateAttribute('crop:'+key,Sdf.ValueTypeNames.String,custom=True).Set(value)
                prim.CreateAttribute('crop:bedId',Sdf.ValueTypeNames.Int,custom=True).Set(bed['id'])
                if local['connect_stems'] and np.linalg.norm(endpoint-anchor)>1e-6:
                    connector(stage,base+f'/Connectors/Stem_{index+1:04d}',anchor,endpoint,local['stem_radius_m'],mat)
                accepted.append((center,radius))
                fruits.append({'path':path,'tree':treepath,'bed':bed['id'],'color':color,'center_local':center.tolist(),
                    'center_world':transform_points([center],bed['matrix'])[0].tolist(),'radius_m':radius,'scale':scale,
                    'yaw_deg':yaw,'side':side,'wire_clearance_lower_bound_m':abs(center[0]-bed['x'])-radius-bed['outer_half_width'],
                    'connector_length_m':float(np.linalg.norm(endpoint-anchor))})
        # Author a useful review camera without changing background camera settings.
        cam=UsdGeom.Camera.Define(stage,'/World/Vegetation/ReviewCamera')
        cam.CreateFocalLengthAttr(25);cam.CreateClippingRangeAttr(Gf.Vec2f(.05,200))
        view=Gf.Matrix4d().SetLookAt(Gf.Vec3d(-.15,-11.5,2.1),Gf.Vec3d(-2,-5,1.2),Gf.Vec3d(0,0,1))
        cam.AddTransformOp().Set(view.GetInverse())
        stage.GetRootLayer().Save()
        report={'background':relative(bg,ROOT),'output':relative(output,ROOT),'seed':cfg['seed'],
            'bed_count':len(beds),'tree_count':len(trees),'fruit_count':len(fruits),'warnings':warnings,
            'trees':trees,'fruits':fruits}
        report_temp=output.with_suffix('.report.building.json')
        report_temp.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
        # Drop stage/layer references before replacing the file (also works on Windows).
        stage=None
        os.replace(temporary,output)
        os.replace(report_temp,output.with_suffix(".report.json"))
        print(f"Saved {output} | beds={len(beds)}, trees={len(trees)}, fruits={len(fruits)}")
        for warning in warnings:print("NOTICE:",warning)
    except Exception:
        stage=None
        if temporary.exists():temporary.unlink()
        raise
    return output
